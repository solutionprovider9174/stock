<div class="wrap">
  <h2><?php print self::NAME?></h2>

  <div class="<?php print self::CODE?>-inline-field">
    <h4>Heat map type</h4>
    <select class="<?php print self::CODE?>-param" name="type">
      <option value="forex">Forex Market</option>
      <option value="stock">Stock Market</option>
    </select>
  </div>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Background color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="background" value="#fff">
    </div>
  </div>

  <div>
    <input id="<?php print self::CODE?>-preview-button" type="button" value="Preview heat map">
  </div>

  <h4>Heat map shortcode</h4>
  <div>
    <input type="text" id="<?php print self::CODE?>-shortcode" readonly>
  </div>

  <h4>Chart preview</h4>
  <div id="<?php print self::CODE?>-preview-container"></div>
</div>