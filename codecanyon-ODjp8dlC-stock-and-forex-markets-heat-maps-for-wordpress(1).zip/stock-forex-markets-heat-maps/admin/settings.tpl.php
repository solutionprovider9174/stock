<div class="ifc-wrapper">
  <?php if (!$this->config->OpenExchangeRatesAppID):?>
    <div class="notice notice-warning">
      <p>This plugin uses <a href="https://openexchangerates.org/" target="_blank">OpenExchangeRate API</a> to retrieve currencies rates.
        Please <a href="https://openexchangerates.org/signup/free" target="_blank">sign up</a> for free and obtain an individual API key (App ID).
        Input the App ID key below.
      </p>
    </div>
  <?php elseif($settingsSaved):?>
    <div class="notice notice-success">
      <p>
        Settings are successfully saved. You will be redirected to the chart configuration page now.
      </p>
    </div>
    <script>
      (function ($) {
        setTimeout(function () {
          location.href='<?php print $_SERVER["SCRIPT_NAME"]?>?page=<?php print self::ID?>';
        }, 2500);
      })(jQuery);
    </script>
  <?php endif;?>

  <h1><?php print self::NAME?></h1>

  <div class="ifc-settings-wrapper">
    <h3>Plugin settings</h3>

    <form method="post" action="<?php print $_SERVER['REQUEST_URI']?>">
      <table class="form-table">
        <tbody>
        <tr>
          <th scope="row">
            <label for="quandlKey">OpenExchangeRates App ID</label>
          </th>
          <td>
            <input type="text" name="OpenExchangeRatesAppID" value="<?php print $this->config->OpenExchangeRatesAppID?>" class="regular-text">
          </td>
        </tr>
        </tbody>
      </table>
      <input type="submit" value="Save settings" class="button button-primary">
    </form>
  </div>
</div>