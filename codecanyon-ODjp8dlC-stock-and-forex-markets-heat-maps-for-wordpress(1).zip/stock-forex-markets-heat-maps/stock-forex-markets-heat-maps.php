<?php
/**
 * Plugin Name: Stock and Forex Markets Heat Maps
 * Description: Plugin displays a world map with countries colored according to how their major stock indices perform or how their national currency is traded against USD at the moment.
 * Version: 1.2.3, built on Monday, October 15, 2018
 * Author: Financial Apps and Plugins <info@financialplugins.com>
 * Author URI: https://financialplugins.com/
 * Plugin URI: https://financialplugins.com/products/stock-forex-markets-heat-maps/
 * Purchase: https://codecanyon.net/item/stock-and-forex-markets-heat-maps-for-wordpress/19029924?ref=financialtechnology
 * Like: https://www.facebook.com/webthegap/
 */

class StockForexMarketsHeatMap {
  const VERSION      = '1.2.2';
  const CODE         = 'wsmhm';
  const ID           = 'stock-forex-markets-heat-maps';
  const NAME         = 'Stock and Forex Markets Heat Maps';
  const SHORTCODE    = 'stock_forex_markets_heat_map';
  const JS_OBJ       = 'wsmhmWordpressOptions';
  const JS_OBJ_ADMIN = 'wsmhmWordpressOptionsAdmin';
  const ENV          = 'config/env.json';
  const CONFIG       = 'vendor/stock-forex-markets-heat-maps/config/env.json';
  private $env; // $env->debug
  private $config;
  private $pluginDir;
  private $pluginUrl;

  function __construct() {
    $this->pluginDir = plugin_dir_path(__FILE__);
    $this->pluginUrl = plugin_dir_url(__FILE__);
    $this->env = $this->loadJSON(self::ENV);
    $this->config = $this->loadJSON(self::CONFIG);

    add_shortcode(self::SHORTCODE, [$this, 'shortcode']);
    add_action('wp_enqueue_scripts',        [$this,'loadAssets']);
    add_action('admin_init',                [$this,'adminInit']);
    add_action('admin_menu',                [$this,'addAdminMenu']);
    add_action('admin_enqueue_scripts',     [$this,'loadAdminAssets']);
    add_filter('plugin_action_links_'.plugin_basename(__FILE__), [$this, 'addPluginActionLinks']);
    $this->addAjaxHandler('processShortcode');
  }

  private function addAjaxHandler($name) {
    add_action('wp_ajax_'.self::CODE.'_'.$name,  [$this,'ajax_'.$name]);
  }

  /**
   * Return shortcode HTML
   * @param $shortcodeParams
   * @return string
   */
  public function shortcode($shortcodeParams) {
    ob_start();
    include $this->pluginDir . '/admin/shortcode.tpl.php';
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
  }

  /**
   * Get shortcode HTML based on parameters passed via POST request
   */
  public function ajax_processShortcode() {
    $shortcodeParams = isset($_POST['shortcodeParams']) ? (array)$_POST['shortcodeParams'] : [];
    print $this->shortcode($shortcodeParams);
    wp_die();
  }

  /**
   * Load assets for non-admin users
   */
  public function loadAssets() {
    $this->loadStyles();
    $this->loadScripts();
  }

  /**
   * Load assets for admin users
   */
  public function loadAdminAssets() {
    $this->loadStyles();
    $this->loadScripts();
    $this->loadAdminStyles();
    $this->loadAdminScripts();
  }

  public function loadStyles() {
    $this->loadStyle('plugin_style',    'vendor/stock-forex-markets-heat-maps/assets/css/wsmhm-style.css');
  }

  public function loadScripts() {
    $this->loadScript('gcharts',          'https://www.gstatic.com/charts/loader.js');
    $this->loadScript('plugin_main',      'vendor/stock-forex-markets-heat-maps/assets/js/wsmhm-app'.($this->env->debug?'':'.min').'.js', ['jquery']);
    $this->localizeScript('plugin_main', self::JS_OBJ, [
      'pluginBasePath' => $this->pluginUrl . 'vendor/stock-forex-markets-heat-maps/',
      'debug'          => $this->env->debug
    ]);
  }

  private function loadAdminScripts() {
    $this->loadScript('plugin_admin', 'js/admin'.($this->env->debug?'':'.min').'.js', ['jquery']);
    $this->loadScript('spectrum', 'vendor/spectrum/spectrum.js', ['jquery']);
    $this->localizeScript('plugin_admin', self::JS_OBJ_ADMIN, [
      'pluginCode'     => self::CODE,
      'shortcode'      => self::SHORTCODE,
      'debug'          => $this->env->debug,
      'jsScriptUrl'    => $this->pluginUrl.'vendor/stock-forex-markets-heat-maps/assets/js/wsmhm-app'.($this->env->debug?'':'.min').'.js'
    ]);
  }

  public function loadAdminStyles() {
    $this->loadStyle('plugin_admin', 'css/admin.css');
    $this->loadStyle('spectrum', 'vendor/spectrum/spectrum.css');
    $this->loadStyle('font_awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css');
  }

  /**
   * Customize plugin action links on plugins page
   * @param $links
   * @return mixed
   */
  public function addPluginActionLinks($links) {
    $link = '<a href="https://codecanyon.net/downloads" target="_blank"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i> Rate plugin</a>';
    array_unshift($links, $link);
    return $links;
  }

  /**
   * Init function for admin
   */
  public function adminInit() {

  }
  public function addAdminMenu() {
    if ($this->config->OpenExchangeRatesAppID) {
      add_menu_page(self::ID, self::NAME, 'edit_posts', self::ID, [$this, 'renderChartSetupPage']);
      add_submenu_page(self::ID, self::NAME, 'Settings', 'edit_posts', self::ID . '-settings', [$this, 'displayPluginSettingsPage']);
    } else {
      add_menu_page(self::NAME, self::NAME, 'edit_posts', self::ID . '-settings', [$this, 'displayPluginSettingsPage']);
    }
  }

  /**
   * Display chart setup page
   */
  public function renderChartSetupPage() {
    if ($this->config->OpenExchangeRatesAppID) {
      require_once('admin/chart.tpl.php');
    } else {
      wp_redirect($_SERVER['REQUEST_URI'].'-settings', 302);
      exit;
    }
  }

  public function displayPluginSettingsPage() {
    $settingsSaved = FALSE;
    if (!empty($_POST)) {
      $this->config->OpenExchangeRatesAppID = isset($_POST['OpenExchangeRatesAppID']) ? $_POST['OpenExchangeRatesAppID'] : '';
      $settingsSaved = $this->saveJSON(self::CONFIG, $this->config);
    }
    require_once('admin/settings.tpl.php');
  }

  /**
   * Enqueue style
   * @param $code
   * @param $filePath
   * @param array $dependencies
   */
  private function loadStyle($code, $filePath, $dependencies = []) {
    wp_enqueue_style(self::CODE . '_' . $code, substr($filePath,0,4)!='http' ? $this->pluginUrl . $filePath : $filePath, $dependencies, self::VERSION);
  }

  /**
   * Enqueue JavaScript
   * @param $code
   * @param $filePath
   * @param array $dependencies
   * @param bool|FALSE $inFooter
   */
  private function loadScript($code, $filePath, $dependencies = [], $inFooter = FALSE) {
    wp_enqueue_script(self::CODE . '_' . $code, substr($filePath,0,4)!='http' ? $this->pluginUrl . $filePath : $filePath, $dependencies, self::VERSION, $inFooter);
  }

  /**
   * Add custom JavaScript variables
   * @param $code
   * @param $objectName
   * @param $objectProperties
   */
  private function localizeScript($code, $objectName, $objectProperties) {
    wp_localize_script(self::CODE . '_' . $code, $objectName, $objectProperties);
  }

  private function loadJSON($fileName) {
    return json_decode(file_get_contents($this->pluginDir . $fileName));
  }

  private function saveJSON($fileName, $contents) {
    return file_put_contents($this->pluginDir . $fileName, json_encode($contents));
  }
}

$stockForexMarketsHeatMap = new StockForexMarketsHeatMap();

?>