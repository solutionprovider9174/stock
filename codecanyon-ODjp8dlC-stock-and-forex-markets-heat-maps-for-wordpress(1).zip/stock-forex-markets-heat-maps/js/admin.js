"use strict";
(function ($) {
  $(document).ready(function () {
    var code = wsmhmWordpressOptionsAdmin.pluginCode;
    setShortcode();

    // On Preview button click
    $('#'+code+'-preview-button').on('click', function () {
      setShortcode();

      // process shortcode on WP side and get the result HTML
      $.ajax({
        url: ajaxurl,
        method:   'POST',
        dataType: 'html',
        data: {
          action:          code+'_processShortcode',
          shortcodeParams: {settings: getShortcodeParams().join(';')}
        },
        success: function (shortcodeHTML) {
          log('processShortcode', shortcodeHTML);
          $('#' + code + '-preview-container').empty().append(shortcodeHTML);
          // reload JS script, so it reads the chart settings again
          reloadScript(wsmhmWordpressOptionsAdmin.jsScriptUrl);
        }
      });
    });

    // auto select short code
    $('#'+code+'-shortcode').focus(function(){
      this.select();
    });

    // init color pickers
    $('.'+code+'-color-picker').spectrum({
      preferredFormat: 'hex3',
      showInput: true,
      showPalette: true
    });

    // show/hide scrollbar related settings when checkbox is set/unset
    $('input[type=checkbox].'+code+'-param').on('change', function () {
      var $this = $(this);
      var checked = $this.prop('checked');
      $this.val(checked);
      if (checked) {
        $('.'+code+'-scrollbar-params').show();
      } else {
        $('.'+code+'-scrollbar-params').hide();
      }
    });
  });

  /**
   * Format shortcode and display it
   */
  function setShortcode() {
    var code = wsmhmWordpressOptionsAdmin.pluginCode;
    var params = getShortcodeParams();
    var shortcodeString = '[' + wsmhmWordpressOptionsAdmin.shortcode + ' settings="' + params.join(';') + '"]';
    $('#'+code+'-shortcode').val(shortcodeString);
  }

  /**
   * Get shortcode params as an array of 'key = value' strings
   * @returns {Array}
   */
  function getShortcodeParams() {
    var code = wsmhmWordpressOptionsAdmin.pluginCode;
    var params = [];
    $('.'+code+'-param').each(function(i, param) {
      var $param = $(param);
      params.push($param.attr('name') + '=' + $param.val());
    });
    return params;
  }

  /**
   * Reload and rerun JS script
   * @param src - script src (URL)
   */
  function reloadScript(src) {
    $('script[src="' + src + '"]').remove();
    $('<script>').attr('src', src).appendTo('head');
  }

  /**
   * Log message to console
   */
  function log() {
    if (typeof wsmhmWordpressOptionsAdmin != 'undefined' && wsmhmWordpressOptionsAdmin.debug) {
      console.log(arguments);
    }
  }
})(jQuery);