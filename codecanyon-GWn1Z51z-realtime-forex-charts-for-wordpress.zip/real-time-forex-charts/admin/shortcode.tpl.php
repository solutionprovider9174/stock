<div id="realtime-fx-chart"></div>
<?php if(isset($shortcodeParams['settings'])):?>
<script type="text/javascript">
  function RealtimeForexChartsOptions() {
    <?php foreach(explode(';',$shortcodeParams['settings']) as $setting):?>
      <?php list($param, $value) = explode('=',$setting)?>
      this.<?php print $param . '=' . (intval($value)>0 || in_array($value, ['true','false']) ? $value : '"'.$value.'"')?>;
    <?php endforeach;?>
  }
</script>
<?php endif;?>