<div class="wrap">
  <h2><?php print self::NAME?></h2>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Default currency pair</h4>
      <select class="<?php print self::CODE?>-param" name="defaultAsset">
        <?php foreach($this->assets as $code => $name):?>
          <option value="<?php print $code?>"><?php print $name?></option>
        <?php endforeach;?>
      </select>
    </div>

    <div class="<?php print self::CODE?>-inline-field">
      <h4>Default chart type</h4>
      <select class="<?php print self::CODE?>-param" name="defaultChartType">
        <option value="line">Line</option>
        <option value="smoothedLine">Smoothed line</option>
        <option value="step">Step</option>
        <option value="smoothedLineArea">Area</option>
        <option value="candlestick">Candlestick</option>
      </select>
    </div>
  </div>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Background color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="backgroundColor" value="#fff">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Line color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="lineColor" value="#00b5ad">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Negative line color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="negativeLineColor" value="#FF2330">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Text color of value axis</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="valuesTextColor" value="#3B06BA">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Legend text color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="legendTextColor" value="#000">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Grid color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="gridColor" value="#ccc">
    </div>
  </div>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Chart line thickness</h4>
      <input type="text" class="<?php print self::CODE?>-param" name="lineThickness" value="1">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Grid thickness</h4>
      <input type="text" class="<?php print self::CODE?>-param" name="gridColorThickness" value="1">
    </div>
  </div>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Balloon text color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="balloonTextColor" value="#000">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Balloon fill color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="balloonFillColor" value="#fff">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Cursor color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="cursorLineColor" value="green">
    </div>
  </div>

  <div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Enable scrollbar</h4>
      <input type="checkbox" class="<?php print self::CODE?>-param" name="scrollbarEnabled" checked value="1">
    </div>
  </div>

  <div class="<?php print self::CODE?>-scrollbar-params">
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar height (in px)</h4>
      <input type="text" class="<?php print self::CODE?>-param" name="scrollbarHeight" value="100">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar text color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarTextColor" value="#fff">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar grid color</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarGridColor" value="#fff">
    </div>
  </div>

  <div class="<?php print self::CODE?>-scrollbar-params">
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar background color (inactive)</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarBackgroundColor" value="grey">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar background color (active)</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarSelectedBackgroundColor" value="#E0E0E0">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar fill color (inactive)</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarGraphFillColor" value="#2C8B86">
    </div>
    <div class="<?php print self::CODE?>-inline-field">
      <h4>Scrollbar fill color (active)</h4>
      <input class="<?php print self::CODE?>-param <?php print self::CODE?>-color-picker" name="scrollbarSelectedGraphFillColor" value="#00b5ad">
    </div>
  </div>

  <div>
    <input id="<?php print self::CODE?>-preview-button" type="button" value="Preview chart">
  </div>

  <h4>Chart shortcode</h4>
  <div>
    <input type="text" id="<?php print self::CODE?>-shortcode" readonly>
  </div>

  <h4>Chart preview</h4>
  <div id="<?php print self::CODE?>-chart-preview"></div>
</div>