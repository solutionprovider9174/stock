<?php
/**
 * Plugin Name: Real-time FOREX Charts for WordPress
 * Description: Plugin, which allows you to add interactive FOREX charts updated in real-time to your website. All major currency pairs are supported.
 * Version: 1.2.1, built on Sunday, March 17, 2019
 * Author: WebTheGap <mail@webthegap.com>
 * Author URI: http://webthegap.com/
 * Plugin URI: http://webthegap.com/products/real-time-forex-charts/
 * Purchase: https://codecanyon.net/item/realtime-forex-charts-for-wordpress/18955147?ref=financialtechnology
 * Like: https://www.facebook.com/webthegap/
 */

class realTimeForexChart {
  const VERSION      = '1.2.1';
  const CODE         = 'rfchart';
  const ID           = 'real-time-forex-charts';
  const NAME         = 'Real-time FOREX Charts';
  const SHORTCODE    = 'real_time_forex_chart';
  const JS_OBJ_ADMIN = 'RealtimeForexChartsWordpressAdmin';
  private $env; // $env->debug
  private $pluginDir;
  private $pluginUrl;
  private $assets;

  function __construct() {
    $this->pluginDir = plugin_dir_path(__FILE__);
    $this->pluginUrl = plugin_dir_url(__FILE__);
    $this->env = $this->loadJSON('config/env.json');

    add_shortcode(self::SHORTCODE, [$this, 'shortcode']);
    add_action('wp_enqueue_scripts',        [$this,'loadAssets']);
    add_action('admin_init',                [$this,'adminInit']);
    add_action('admin_menu',                [$this,'addAdminMenu']);
    add_action('admin_enqueue_scripts',     [$this,'loadAdminAssets']);
    add_action('wp_ajax_processShortcode',  [$this,'processShortcode']);
    add_filter('plugin_action_links_'.plugin_basename(__FILE__), [$this, 'addPluginActionLinks']);
  }

  /**
   * Return shortcode HTML
   * @param $shortcodeParams
   * @return string
   */
  public function shortcode($shortcodeParams) {
    // shortcode() is called each time the plugin is initialized, so need to check if anything was passed or not
    if (empty($shortcodeParams)) return;

    ob_start();
    include $this->pluginDir . '/admin/shortcode.tpl.php';
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
  }

  /**
   * Get shortcode HTML based on parameters passed via POST request
   */
  public function processShortcode() {
    $shortcodeParams = isset($_POST['shortcodeParams']) ? (array)$_POST['shortcodeParams'] : [];
    print $this->shortcode($shortcodeParams);
    wp_die();
  }

  /**
   * Load assets for non-admin users
   */
  public function loadAssets() {
    $this->loadStyles();
    $this->loadScripts();
  }

  /**
   * Load assets for admin users
   */
  public function loadAdminAssets() {
    $this->loadStyles();
    $this->loadScripts();
    $this->loadAdminStyles();
    $this->loadAdminScripts();
  }

  public function loadStyles() {
    $this->loadStyle('amcharts_export', 'vendor/amcharts/plugins/export/export.css');
    $this->loadStyle('plugin_style',    'vendor/real-time-forex-charts/realtime-forex-charts.css');
  }

  public function loadScripts() {
    $this->loadScript('amchart_main',     'vendor/amcharts/amcharts.js', ['jquery']);
    $this->loadScript('amchart_serial',   'vendor/amcharts/serial.js', ['jquery']);
    $this->loadScript('amchart_stock',    'vendor/amcharts/amstock.js', ['jquery']);
    $this->loadScript('amchart_export',   'vendor/amcharts/plugins/export/export.min.js', ['jquery']);
    $this->loadScript('plugin_main',      'vendor/real-time-forex-charts/realtime-forex-charts'.($this->env->debug?'':'.min').'.js', ['jquery']);
    $this->localizeScript('plugin_main', 'RealtimeForexChartsWordpressOptions', [
      'pluginUrl' => $this->pluginUrl,
      'debug'     => $this->env->debug
    ]);
  }

  private function loadAdminScripts() {
    $this->loadScript('plugin_admin', 'js/admin'.($this->env->debug?'':'.min').'.js', ['jquery']);
    $this->loadScript('spectrum', 'vendor/spectrum/spectrum.js', ['jquery']);
    $this->localizeScript('plugin_admin', self::JS_OBJ_ADMIN, [
      'pluginCode'     => self::CODE,
      'shortcode'      => self::SHORTCODE,
      'debug'          => $this->env->debug,
      'chartScriptUrl' => $this->pluginUrl.'vendor/real-time-forex-charts/realtime-forex-charts'.($this->env->debug?'':'.min').'.js'
    ]);
  }

  public function loadAdminStyles() {
    $this->loadStyle('plugin_admin', 'css/admin.css');
    $this->loadStyle('spectrum', 'vendor/spectrum/spectrum.css');
    $this->loadStyle('font_awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css');
  }

  /**
   * Customize plugin action links on plugins page
   * @param $links
   * @return mixed
   */
  public function addPluginActionLinks($links) {
    $link = '<a href="https://codecanyon.net/downloads" target="_blank"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i> Rate plugin</a>';
    array_unshift($links, $link);
    return $links;
  }

  /**
   * Init function for admin
   */
  public function adminInit() {
    $this->assets = $this->loadJSON('config/currencies.json');
  }
  public function addAdminMenu() {
    add_menu_page(self::ID, self::NAME, 'edit_posts', self::ID, [$this, 'renderAdminMenuPage']);
  }

  /**
   * Display chart settings page
   */
  public function renderAdminMenuPage() {
    require_once('admin/settings.tpl.php');
  }

  /**
   * Enqueue style
   * @param $code
   * @param $filePath
   * @param array $dependencies
   */
  private function loadStyle($code, $filePath, $dependencies = []) {
    wp_enqueue_style(self::CODE . '_' . $code, strpos($filePath,'http')===FALSE ? $this->pluginUrl . $filePath : $filePath, $dependencies, self::VERSION);
  }

  /**
   * Enqueue JavaScript
   * @param $code
   * @param $filePath
   * @param array $dependencies
   * @param bool|FALSE $inFooter
   */
  private function loadScript($code, $filePath, $dependencies = [], $inFooter = FALSE) {
    wp_enqueue_script(self::CODE . '_' . $code, $this->pluginUrl . $filePath, $dependencies, self::VERSION, $inFooter);
  }

  /**
   * Add custom JavaScript variables
   * @param $code
   * @param $objectName
   * @param $objectProperties
   */
  private function localizeScript($code, $objectName, $objectProperties) {
    wp_localize_script(self::CODE . '_' . $code, $objectName, $objectProperties);
  }
  private function loadJSON($fileName) {
    return json_decode(file_get_contents($this->pluginDir . $fileName));
  }
}

$realTimeForexChart = new realTimeForexChart();

?>