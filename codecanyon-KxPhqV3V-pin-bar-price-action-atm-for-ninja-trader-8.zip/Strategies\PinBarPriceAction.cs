#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class PinBarPriceAction : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Reversal therapy in the formation of a pinbar";
				Name										= "PinBarPriceAction";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				NumberOfСontracts			= 1;
				StopLoss					= 0.01;
				StopProfit					= 0.01;
			}
			else if (State == State.Configure)
			{
				SetStopLoss("", CalculationMode.Percent, StopLoss, false);
				SetProfitTarget("", CalculationMode.Percent, StopProfit);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 1)
				return;
			
			// Pinbar body sizing for sale
			
			double DifferenceHiLowS   = High[0] - Low[0];
			
			double PinbarBodyPlannedS = DifferenceHiLowS/4; 
			
			double PinbarBodyActualS  = Close[0]-Open[0]; 
			
			// Pinbar body sizing for buy
			
			double DifferenceHiLowB   = High[0] - Low[0];
			
			double PinbarBodyPlannedB = DifferenceHiLowB/4; 
			
			double PinbarBodyActualB  = Open[0]-Close[0]; 
			
			 // Set 1
			if ((Open[0] < Close[0])
				 && (High[0] > Close[0])
				 && (Open[0] == Low[0])
				 && (PinbarBodyActualS <= PinbarBodyPlannedS))
			{
				EnterShort(Convert.ToInt32(NumberOfСontracts), "");
			}
			
			 // Set 2
			if ((Open[0] > Close[0])
				 && (Low[0] < Close[0])
				 && (Open[0] == High[0])
				 && (PinbarBodyActualB <= PinbarBodyPlannedB))
			{
				EnterLong(Convert.ToInt32(NumberOfСontracts), "");
			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="NumberOfСontracts", Order=1, GroupName="Parameters")]
		public int NumberOfСontracts
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="StopLoss", Description="Stop loss", Order=2, GroupName="Parameters")]
		public double StopLoss
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="StopProfit", Description="Stop profit", Order=3, GroupName="Parameters")]
		public double StopProfit
		{ get; set; }
		#endregion

	}
}
